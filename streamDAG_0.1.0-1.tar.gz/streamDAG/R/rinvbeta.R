#-- Random inverse-beta outcome(s) --#
rinvbeta <- function(n, alpha, beta){
  1/rbeta(n, alpha, beta)
}
