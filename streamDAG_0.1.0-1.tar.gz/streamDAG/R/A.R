A <- function(G, P = NULL, path = NULL){
  E(graph = G, P = P, path = path, directed = TRUE)
}