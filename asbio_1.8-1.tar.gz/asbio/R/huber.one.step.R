huber.one.step<-function(x,c=1.28){
mu.hat<-huber.NR(x,c,1)[2]
mu.hat
}