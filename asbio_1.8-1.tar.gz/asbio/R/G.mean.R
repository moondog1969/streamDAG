G.mean<-function(x){
x<-na.omit(x)
(prod(x))^(1/length(x))
}
